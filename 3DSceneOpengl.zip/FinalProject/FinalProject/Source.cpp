#include <stdlib.h>
#include "glut.h"

#include <math.h>

//angle of rotation
float xpos = 0, ypos = 0, zpos = 0, xrot = 0, yrot = 0, angler = 0.0;

// CALLBACK functions for GLU_TESS ////////////////////////////////////////////
// NOTE: must be declared with CALLBACK directive
void CALLBACK tessBeginCB(GLenum which);
void CALLBACK tessEndCB();
void CALLBACK tessErrorCB(GLenum errorCode);
void CALLBACK tessVertexCB(const GLvoid *data);

// GLUT CALLBACK functions ////////////////////////////////////////////////////
void display();
void reshape(int w, int h);
void keyboard(unsigned char key, int x, int y);


// function declarations //////////////////////////////////////////////////////
void init();
void initLights();
void setCamera(float posX, float posY, float posZ, float targetX, float targetY, float targetZ);
void draw_BlackArea();
void draw_whiteArea();
void initRendering();

GLuint tessellate();

int drawMode = 0;
GLuint listId1, listId2;       // IDs of display lists


GLuint tessellate()
{
	GLuint id = glGenLists(1);  // create a display list
	if (!id) return id;          // failed to create a list, return 0

	GLUtesselator *tess = gluNewTess(); // create a tessellator
	if (!tess) return 0;         // failed to create tessellation object, return 0

	GLdouble quad2[8][3] = { { -4,3,0 },{ -4,0,0 },{ 4,0,0 },{ 4,3,0 },
	{ -2,2,0 },{ -2,1,0 },{ 2,1,0 },{ 2,2,0 } };

	// register callback functions
	gluTessCallback(tess, GLU_TESS_BEGIN, (void(__stdcall*)(void))tessBeginCB);
	gluTessCallback(tess, GLU_TESS_END, (void(__stdcall*)(void))tessEndCB);
	gluTessCallback(tess, GLU_TESS_ERROR, (void(__stdcall*)(void))tessErrorCB);
	gluTessCallback(tess, GLU_TESS_VERTEX, (void(__stdcall*)())tessVertexCB);

	// tessellate and compile a concave quad into display list
	glNewList(id, GL_COMPILE);
	glColor3f(1, 1, 1);
	gluTessBeginPolygon(tess, 0);                       // with NULL data
	gluTessBeginContour(tess);                      // outer quad
	gluTessVertex(tess, quad2[0], quad2[0]);
	gluTessVertex(tess, quad2[1], quad2[1]);
	gluTessVertex(tess, quad2[2], quad2[2]);
	gluTessVertex(tess, quad2[3], quad2[3]);
	gluTessEndContour(tess);
	gluTessBeginContour(tess);                      // inner quad (hole)
	gluTessVertex(tess, quad2[4], quad2[4]);
	gluTessVertex(tess, quad2[5], quad2[5]);
	gluTessVertex(tess, quad2[6], quad2[6]);
	gluTessVertex(tess, quad2[7], quad2[7]);
	gluTessEndContour(tess);
	gluTessEndPolygon(tess);
	glEndList();

	gluDeleteTess(tess);        // delete after tessellation

	return id;      // return handle ID of a display list
}
void init()
{
	glShadeModel(GL_SMOOTH);                    // shading method

		// track material ambient and diffuse from surface color
		glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glClearColor(0, 0, 0, 0);                   // background color
	initLights();
	//set light source
	setCamera(0, 0, 5, 0, 0, 0);
	//set camera
}
void initLights()
{
	// set up light colors (ambient, diffuse, specular)
	GLfloat lightKa[] = { .2f, .2f, .2f, 1.0f };  // ambient light
	GLfloat lightKd[] = { .7f, .7f, .7f, 1.0f };  // diffuse light
	GLfloat lightKs[] = { 1, 1, 1, 1 };           // specular light
	glLightfv(GL_LIGHT0, GL_AMBIENT, lightKa);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightKd);
	glLightfv(GL_LIGHT0, GL_SPECULAR, lightKs);
	// position the light
	float lightPos[4] = { 0, 0, 20, 1 }; // positional light
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
	glEnable(GL_LIGHT0);
}
void setCamera(float posX, float posY, float posZ, float targetX, float targetY, float targetZ)
{
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(posX, posY+2, posZ, targetX, targetY, targetZ, 0, 1, 0); // eye(x,y,z), focal(x,y,z), up(x, y, z);

}
void camera(void) {
	glRotatef(xrot, 1.0, 0.0, 0.0);  //rotate our camera on teh x - axis(left and right)
		glRotatef(yrot, 0.0, 1.0, 0.0);  //rotate our camera on the y - axis(up and down)
		glTranslated(-xpos, -ypos, -zpos); //translate the screento the position of our camera
}


void display() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	//transformation can be applied to the model
	
	camera();
	glBegin(GL_QUADS);
	glColor3f(0.6f, 0.6f, 0.6f);
		glVertex3f(-3, 0, 3);
		glVertex3f(3, 0, 3);
		glVertex3f(3, 0, -3);
		glVertex3f(-3, 0, -3);
	glEnd();  

	glBegin(GL_QUADS);
	glColor3f(0.0f, 0.7f, 0.7f);
	glVertex3f(-3, 3, -3);
	glVertex3f(-3, 3, 3);
	glVertex3f(-3, 0, 3);
	glVertex3f(-3, 0, -3);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0.0f, 0.7f, 0.7f);
	glVertex3f(-3, 0, -3);
	glVertex3f(3, 0, -3);
	glVertex3f(3, 3, -3);
	glVertex3f(-3, 3, -3);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0.0f, 0.7f, 0.7f);
	glVertex3f(3, 3, 3);
	glVertex3f(3, 3, -3);
	glVertex3f(3, 0, -3);
	glVertex3f(3, 0, 3);
	glEnd();

	glPushMatrix();
	glTranslatef(0, 0, -4);
	glCallList(listId1);
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0, 0, -2.9);
	glRotatef(180, 0, 1, 0);
	glCallList(listId1);
	glPopMatrix();
	glPushMatrix();
	glTranslatef(2.9, 0, .4);
	glRotatef(-90, 0, 1, 0);
	glCallList(listId1);
	glPopMatrix();
	glPushMatrix();
	glTranslatef(-2.9, 0, .4);
	glRotatef(90, 0, 1, 0);
	glCallList(listId1);
	glPopMatrix();

	glPopMatrix();
	glPushMatrix();
	glColor3f(0.0f, 0.0f, 0.9f);
	glScalef(1, 1, 1);
	glTranslatef(.5, .5, 0);
	glutSolidTeapot(.5);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.7f, 0.0f, 0.0f);
	glScalef(1, 1, 1);
	glTranslatef(1.5, .5, 1);
	glRotatef(90, 0, 1, 0);
	glutSolidTeapot(.5);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.0f, 0.7f, 0.0f);
	glScalef(1, 1, 1);
	glTranslatef(-1.5, .5, 1);
	glutSolidCube(.7);
	glPopMatrix();

	glPushMatrix();
	glColor3f(0.0f, 0.3f, 0.3f);
	glScalef(.25, .25, .25);
		glTranslatef(0, 1, 8);
		glRotatef(90, 1, 0, 0);
	glutSolidTorus(1, 2, 10, 10);
	glPopMatrix();

	glEnd();
	
		 glutSwapBuffers();
		glFlush();

	//if double buffer used
}
void reshape(int w, int h)
{
	// set viewport to be the entire window
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	// set perspective viewing frustum
	float aspectRatio = (float)w / h;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0f, aspectRatio, 1.0f, 1000.0f);
	//glFrustum();
	// switch to modelview matrix in order to set scene
	glMatrixMode(GL_MODELVIEW);
	glEnable(GL_TEXTURE_2D);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
}
// angle of rotation for the camera direction
float angle = 0.0;
// actual vector representing the camera's direction
float lx = 0.0f, lz = -1.0f;
// XZ position of the camera
float x = 0.0f, z = 5.0f;

void processSpecialKeys(int key, int xx, int yy) {

	float fraction = 0.1f;

	switch (key) {
	case GLUT_KEY_LEFT:
		angle -= 0.01f;
		lx = sin(angle);
		lz = -cos(angle);
		break;
	case GLUT_KEY_RIGHT:
		angle += 0.01f;
		lx = sin(angle);
		lz = -cos(angle);
		break;
	case GLUT_KEY_UP:
		x += lx * fraction;
		z += lz * fraction;
		break;
	case GLUT_KEY_DOWN:
		x -= lx * fraction;
		z -= lz * fraction;
		break;
	}
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
		case 'q':
		{
			xrot += 1;
			if (xrot >360) xrot -= 360;
		}
		break;
		case 'z':
		{
			xrot -= 1;
			if (xrot < -360) xrot += 360;
		}
		break;
		case 'w':
		{
			float xrotrad, yrotrad;
			yrotrad = (yrot / 180 * 3.141592654f);
			xrotrad = (xrot / 180 * 3.141592654f);
			xpos += float(sin(yrotrad));
			zpos -= float(cos(yrotrad));
			ypos -= float(sin(xrotrad));
		}
		break;
	case's':
		{
			float xrotrad, yrotrad;
			yrotrad = (yrot / 180 * 3.141592654f);
			xrotrad = (xrot / 180 * 3.141592654f);
			xpos -= float(sin(yrotrad));
			zpos += float(cos(yrotrad));
			ypos += float(sin(xrotrad));
		}
		break;
	case 'd':
		{
			yrot += 1;
			if (yrot >360) yrot -= 360;
		}
		break;
	case  'a':
		{
			yrot -= 1;
			if (yrot < -360)yrot += 360;
		}
		break;
	case 27: // ESCAPE
		exit(0);
		break;

	}
}

	int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(500, 300);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Eric Rivera");
	init();
	listId1 = tessellate();	

	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	//glutIdleFunc(display);
	glutKeyboardFunc(keyboard);
	glutSpecialFunc(processSpecialKeys);
	glutMainLoop(); // Enter the event-processing loop
	return 0;
}

	void CALLBACK tessBeginCB(GLenum which)
	{
		glBegin(which);
	}
	void CALLBACK tessEndCB()
	{
		glEnd();
	}
	void CALLBACK tessVertexCB(const GLvoid *data)
	{
		// cast back to double type
		const GLdouble *ptr = (const GLdouble*)data;

		glVertex3dv(ptr);
	}
	void CALLBACK tessErrorCB(GLenum errorCode)
	{
		const GLubyte *errorStr;

		errorStr = gluErrorString(errorCode);
	}

